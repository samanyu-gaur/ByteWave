import { useNavigate, useLocation } from 'react-router-dom'
import NavBar from '../components/NavBar'
import FeedbackCard from '../components/FeedbackCard'
import MasteryScore from '../components/MasteryScore'
import { ButtonPrimary, ButtonText } from '../components/ButtonPrimary'

const content = {
  display: 'flex',
  flexDirection: 'column',
  gap: 24,
  maxWidth: 640,
  margin: '0 auto',
}

const sampleFeedback =
  "Focus on what slope represents in position–time graphs. You're strong on reading values; try linking slope to velocity next."

export default function Feedback() {
  const navigate = useNavigate()
  const location = useLocation()
  const state = location.state || {}
  const caseTitle = state.caseTitle || 'Position vs time'

  return (
    <>
      <NavBar back title="Feedback" />
      <div style={content}>
        <FeedbackCard
          feedback={sampleFeedback}
          suggestedCase="Velocity vs time"
          onTrySuggested={() => navigate('/learn/assess/velocity-vs-time')}
        />
        <MasteryScore label="Slope" percent={72} />
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16 }}>
          <ButtonPrimary onClick={() => navigate('/learn/skill-map')}>Back to skill map</ButtonPrimary>
          <ButtonText onClick={() => navigate('/learn/choose-case')}>Choose another case</ButtonText>
        </div>
      </div>
    </>
  )
}
