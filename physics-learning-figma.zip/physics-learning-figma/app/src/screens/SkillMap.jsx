import { useNavigate } from 'react-router-dom'
import NavBar from '../components/NavBar'
import SkillMapNode from '../components/SkillMapNode'
import MasteryScore from '../components/MasteryScore'
import { ButtonText } from '../components/ButtonPrimary'
import { FormulaBadge } from '../components/PhysicsGraphic'
import { PHYSICS_TOPICS } from '../physicsTopics'

const content = {
  display: 'flex',
  flexDirection: 'column',
  gap: 24,
}

// Mock state per topic: 4 in-progress, 4 mastered, 4 not-started
const NODE_STATES = ['in-progress', 'in-progress', 'mastered', 'mastered', 'not-started', 'not-started', 'in-progress', 'mastered', 'not-started', 'in-progress', 'mastered', 'not-started']
const nodes = PHYSICS_TOPICS.map((t, i) => ({ ...t, state: NODE_STATES[i] }))

export default function SkillMap() {
  const navigate = useNavigate()
  return (
    <>
      <NavBar back title="Skill map" />
      <div style={content}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 4 }}>
            <h1 className="text-h1" style={{ margin: 0 }}>Physics</h1>
            <FormulaBadge formula="12 nodes" />
          </div>
          <p className="text-body-small" style={{ margin: 0 }}>Pick a topic to practice.</p>
        </div>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: 16,
          }}
        >
          {nodes.map((n) => (
            <SkillMapNode
              key={n.id}
              name={n.name}
              state={n.state}
              topicId={n.id}
              onClick={() => navigate('/learn/choose-case', { state: { skill: n.name, topicId: n.id } })}
            />
          ))}
        </div>
        <MasteryScore label="Physics" percent={72} />
        <ButtonText onClick={() => navigate('/learn')}>Go to dashboard</ButtonText>
      </div>
    </>
  )
}
