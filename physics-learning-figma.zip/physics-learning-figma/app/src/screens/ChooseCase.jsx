import { useNavigate } from 'react-router-dom'
import NavBar from '../components/NavBar'
import CaseCard from '../components/CaseCard'

const content = {
  display: 'flex',
  flexDirection: 'column',
  gap: 24,
}

const cases = [
  { id: 'ramp', title: 'Ramp and block', subtitle: 'Slope on a ramp', topicId: 'kinematics' },
  { id: 'position-vs-time', title: 'Position vs time', subtitle: 'Slope from graph', topicId: 'kinematics' },
  { id: 'velocity-vs-time', title: 'Velocity vs time', subtitle: 'Slope from graph', topicId: 'kinematics' },
  { id: 'two-points', title: 'Two points on a line', subtitle: 'Slope from two points', topicId: 'kinematics' },
]

export default function ChooseCase() {
  const navigate = useNavigate()
  return (
    <>
      <NavBar back title="Choose a case" />
      <div style={content}>
        <div>
          <h1 className="text-h2" style={{ margin: 0 }}>Pick a scenario to practice</h1>
          <p className="text-body-small" style={{ margin: '4px 0 0' }}>Answer questions and get personalised feedback.</p>
        </div>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
            gap: 20,
          }}
        >
          {cases.map((c) => (
            <CaseCard
              key={c.id}
              title={c.title}
              subtitle={c.subtitle}
              topicId={c.topicId}
              onClick={() => navigate(`/learn/assess/${c.id}`)}
            />
          ))}
        </div>
      </div>
    </>
  )
}
