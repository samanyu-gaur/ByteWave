import { useNavigate } from 'react-router-dom'
import MasteryScore from '../components/MasteryScore'
import SectionRow from '../components/SectionRow'
import RecommendationCard from '../components/RecommendationCard'
import CaseCard from '../components/CaseCard'
import { ButtonText } from '../components/ButtonPrimary'
import { FormulaBadge } from '../components/PhysicsGraphic'
import { PHYSICS_TOPICS } from '../physicsTopics'

const content = {
  display: 'flex',
  flexDirection: 'column',
  gap: 32,
}

// Split all 12 topics: 4 Next for you, 4 Review, 4 Ready to master (mock match %)
const NEXT_FOR_YOU = PHYSICS_TOPICS.slice(0, 4).map((t, i) => ({ ...t, matchPercent: [92, 85, 78, 72][i] }))
const REVIEW = PHYSICS_TOPICS.slice(4, 8)
const READY_TO_MASTER = PHYSICS_TOPICS.slice(8, 12)

export default function Home() {
  const navigate = useNavigate()
  return (
    <div style={content}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <h1 className="text-h1" style={{ margin: 0 }}>Hi, Student</h1>
          <FormulaBadge formula="ΣF = ma" />
        </div>
        <p className="text-body-small" style={{ margin: 0 }}>Here’s what’s next.</p>
      </div>
      <MasteryScore label="Physics" percent={72} />
      <ButtonText onClick={() => navigate('/learn/skill-map')}>Open full skill map</ButtonText>
      <SectionRow title="Next for you" formulaSubtitle="high match → start here">
        {NEXT_FOR_YOU.map((t) => (
          <RecommendationCard
            key={t.id}
            title={t.name}
            matchPercent={t.matchPercent}
            topicId={t.id}
            onClick={() => navigate('/learn/choose-case')}
          />
        ))}
      </SectionRow>
      <SectionRow title="Review" formulaSubtitle="keep sharp">
        {REVIEW.map((t) => (
          <CaseCard
            key={t.id}
            title={t.name}
            subtitle={t.description}
            topicId={t.id}
            matchPercent={72}
            onClick={() => navigate('/learn/choose-case')}
          />
        ))}
      </SectionRow>
      <SectionRow title="Ready to master" formulaSubtitle="Δ mastery ≈ 0">
        {READY_TO_MASTER.map((t) => (
          <CaseCard
            key={t.id}
            title={t.name}
            subtitle={t.description}
            topicId={t.id}
            matchPercent={88}
            onClick={() => navigate('/learn/choose-case')}
          />
        ))}
      </SectionRow>
    </div>
  )
}
