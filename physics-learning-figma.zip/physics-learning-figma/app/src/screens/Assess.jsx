import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import NavBar from '../components/NavBar'
import QuestionBlock from '../components/QuestionBlock'
import { ButtonPrimary } from '../components/ButtonPrimary'

const content = {
  display: 'flex',
  flexDirection: 'column',
  gap: 24,
  maxWidth: 640,
  margin: '0 auto',
}

const caseTitles = {
  ramp: 'Ramp and block',
  'position-vs-time': 'Position vs time',
  'velocity-vs-time': 'Velocity vs time',
  'two-points': 'Two points on a line',
}

const questions = [
  'What is the slope of the line?',
  'What does the slope represent in this graph?',
  'If time is in seconds and position in metres, what are the units of slope?',
]

export default function Assess() {
  const { caseId } = useParams()
  const navigate = useNavigate()
  const title = caseTitles[caseId] || 'Assess'
  const [answers, setAnswers] = useState(questions.map(() => ''))

  const setAnswer = (i, value) => {
    setAnswers((prev) => {
      const next = [...prev]
      next[i] = value
      return next
    })
  }

  const handleSubmit = () => {
    navigate('/learn/feedback', { state: { caseId, caseTitle: title, answers } })
  }

  return (
    <>
      <NavBar back title="Assess" />
      <div style={content}>
        <h1 className="text-h2" style={{ margin: 0 }}>{title}</h1>
        {questions.map((q, i) => (
          <QuestionBlock
            key={i}
            question={q}
            value={answers[i]}
            onChange={(v) => setAnswer(i, v)}
          />
        ))}
        <ButtonPrimary block onClick={handleSubmit}>Get feedback</ButtonPrimary>
      </div>
    </>
  )
}
